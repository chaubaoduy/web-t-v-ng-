import { Store } from './store.js';
import { AI } from './ai.js';

class App {
    constructor() {
        this.currentSet = []; // Current working vocab list
        this.init();
    }

    init() {
        // Initial setup
        this.addRow(); // Add one empty row
        this.renderSets();

        // Expose app to window for HTML events
        window.app = this;
    }

    // --- NAVIGATION ---
    navigate(viewId) {
        // Update Sidebar
        document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
        event.currentTarget.classList.add('active');

        // Update View
        document.querySelectorAll('section').forEach(el => el.classList.remove('active'));
        document.getElementById(`view-${viewId}`).classList.add('active');

        if (viewId === 'review') {
            this.renderSets();
        }
    }

    // --- INPUT TABLE LOGIC ---
    addRow(data = null) {
        const tbody = document.getElementById('input-rows');
        const tr = document.createElement('tr');
        const idx = tbody.children.length;

        tr.innerHTML = `
            <td><input type="text" class="vocab-input font-medium text-slate-700" placeholder="Nhập từ..." onblur="app.handleWordInput(this, ${idx})"></td>
            <td><input type="text" class="vocab-input text-slate-500" placeholder="/.../" id="ipa-${idx}"></td>
            <td><input type="text" class="vocab-input text-slate-500" placeholder="n/v/adj..." id="type-${idx}"></td>
            <td><input type="text" class="vocab-input text-slate-500" placeholder="Nghĩa..." id="meaning-${idx}"></td>
            <td><input type="text" class="vocab-input text-slate-500 italic" placeholder="Ví dụ..." id="example-${idx}"></td>
            <td class="text-center">
                <button class="text-slate-300 hover:text-red-500" onclick="this.closest('tr').remove()"><i class="fa-solid fa-trash"></i></button>
            </td>
        `;
        tbody.appendChild(tr);

        // Focus if new row (not initial load)
        if (!data) {
            // tr.querySelector('input').focus();
        }
    }

    async handleWordInput(input, idx) {
        const word = input.value.trim();
        if (!word) return;

        // Visual feedback (loading)
        input.parentElement.classList.add('animate-pulse');

        // Call AI
        const prediction = await AI.predict(word);

        // Fill other fields
        document.getElementById(`ipa-${idx}`).value = prediction.ipa;
        document.getElementById(`type-${idx}`).value = prediction.type;
        document.getElementById(`meaning-${idx}`).value = prediction.meaning;
        document.getElementById(`example-${idx}`).value = prediction.example;

        input.parentElement.classList.remove('animate-pulse');

        // Auto add new row if last row
        const tbody = document.getElementById('input-rows');
        if (tbody.children.length === idx + 1) {
            this.addRow();
        }
    }

    saveSession() {
        const rows = document.querySelectorAll('#input-rows tr');
        const words = [];

        rows.forEach((tr, idx) => {
            const word = tr.querySelector('input:first-child').value;
            if (word) {
                words.push({
                    word: word,
                    ipa: document.getElementById(`ipa-${idx}`).value,
                    type: document.getElementById(`type-${idx}`).value,
                    meaning: document.getElementById(`meaning-${idx}`).value,
                    example: document.getElementById(`example-${idx}`).value
                });
            }
        });

        if (words.length === 0) {
            alert('Chưa có từ vựng nào để lưu!');
            return;
        }

        const newSet = {
            id: `set_${Date.now()}`,
            timestamp: new Date().toLocaleString('vi-VN'),
            wordCount: words.length,
            words: words
        };

        Store.saveSet(newSet);
        alert('Đã lưu thành công! Chuyển sang phần "Kho lưu trữ" để xem.');

        // Reset table
        document.getElementById('input-rows').innerHTML = '';
        this.addRow();
        this.navigate('review');
    }

    // --- REVIEW LOGIC ---
    renderSets() {
        const sets = Store.getSets();
        const grid = document.getElementById('sets-grid');
        grid.innerHTML = '';

        if (sets.length === 0) {
            grid.innerHTML = `<p class="col-span-3 text-center text-slate-400 py-10">Chưa có bộ từ vựng nào. Hãy vào phần "Từ vựng cần học" để tạo mới.</p>`;
            return;
        }

        sets.forEach(set => {
            const card = document.createElement('div');
            card.className = 'bg-white p-5 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-all group relative';
            card.innerHTML = `
                <div class="flex justify-between items-start mb-4">
                    <div class="w-10 h-10 rounded-full bg-sky-100 flex items-center justify-center text-sky-500 font-bold text-lg">
                        ${set.wordCount}
                    </div>
                    <button class="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity" title="Xóa" onclick="app.deleteSet('${set.id}')">
                        <i class="fa-solid fa-trash-can"></i>
                    </button>
                </div>
                <h3 class="font-bold text-slate-800 text-lg mb-1">Bộ từ vựng ${set.timestamp.split(' ')[0]}</h3>
                <p class="text-slate-400 text-sm mb-4"><i class="fa-regular fa-clock mr-1"></i> ${set.timestamp.split(' ')[1]}</p>
                
                <button class="w-full py-2 rounded-lg bg-slate-50 text-slate-600 hover:bg-sky-50 hover:text-sky-600 font-medium transition-colors border border-slate-100">
                    Xem chi tiết
                </button>
            `;
            grid.appendChild(card);
        });
    }

    deleteSet(id) {
        if (confirm('Bạn có chắc muốn xóa bộ từ này?')) {
            Store.deleteSet(id);
            this.renderSets();
        }
    }

    // --- GAMES (Placeholder) ---
    startGame(gameType) {
        alert('Chức năng Game sẽ được cập nhật ở bước tiếp theo!');
    }
}

// Initialize
new App();
