# Visual Vocab

A visual vocabulary web application built with Vanilla JavaScript.

## How to Run Locally

1. Clone the repository.
2. Open `index.html` in your web browser.
   - Or run a local server: `npx serve .`

## Deployment

Deploy on [Vercel](https://vercel.com) or [GitHub Pages](https://pages.github.com).
