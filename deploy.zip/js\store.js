export const Store = {
    KEYS: {
        VOCAB: 'visual_vocab_sets',
        GAMES: 'visual_vocab_games'
    },

    getSets() {
        const data = localStorage.getItem(this.KEYS.VOCAB);
        return data ? JSON.parse(data) : [];
    },

    saveSet(newSet) {
        const sets = this.getSets();
        sets.unshift(newSet); // Add to top
        localStorage.setItem(this.KEYS.VOCAB, JSON.stringify(sets));
        return true;
    },

    deleteSet(id) {
        const sets = this.getSets().filter(s => s.id !== id);
        localStorage.setItem(this.KEYS.VOCAB, JSON.stringify(sets));
    },

    getResults() {
        const data = localStorage.getItem(this.KEYS.GAMES);
        return data ? JSON.parse(data) : [];
    },

    saveResult(result) {
        const results = this.getResults();
        results.unshift(result);
        localStorage.setItem(this.KEYS.GAMES, JSON.stringify(results));
    }
};
